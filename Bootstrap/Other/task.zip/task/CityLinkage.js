/**
 * CityLinkage 1.0
 */

(function($){
  "use strict";

  var CityLinkage = (function(){
    function CityLinkage(element, options){
      this.settings = $.extend(true, $.fn.CityLinkage.defaults, options||{});
      this.element  = element;
      this.init();
    }

    CityLinkage.prototype = {

      /**
       * [init 初始化插件]
       * [初始化DOM结构及绑定事件]
       */
      init : function(){
        var me  = this,
            ses = me.element.children("select");

        me.ajax(0, '' , false);
        me.addElement(ses.eq(0));

        for(let i in ses){
          i != 2 ? ses.eq(i).bind("change",function(){
            me.ajax(i, this.value, true);
            me.addElement(ses.eq(i++));
          }):false;
        };
      },

      /**
       * [ajax 异步获取数据]
       * @param  {[Numbeer]}  rank   [层级]
       * @param  {[String]}   value  [选中值]
       * @param  {[Boolean]}  isNext [是否联动]
       */
      ajax : function(rank,value,isNext){
        var me = this;
        $.ajax({
          type : 'POST',
          url : this.settings.url,
          data : {
            tier : rank,  //层级
            site : value, //选中值
            next : isNext //是否联动
          },
          dataFilter : function(data){
            return JSON.parse(data);
          },
          success : function(data){
            me.results(data);
          },
          error : function(xhr){
            console.log(xhr.state);
          }
        });
      },

      /**
       * [callback ajax success]
       * @return {object} [结果集]
       */
      results : function(data){
        console.log('test');
        console.log(data);
        // return data;
      },

      /**
       * [addElement 填充元素项]
       * @param {[element]} elements [操作元素]
       */
      addElement : function(element){
        console.log(this.results());
        for(let i in this.results()){
          element.append("<option value=" + i + ">" + data[i] + "</option>");
        }
      }

    }
    return CityLinkage;
  })();

  $.fn.CityLinkage = function(options){
    return this.each(function(){
      var me = $(this),
        instance = me.data("CityLinkage");
      if(!instance){
        me.data("CityLinkage", (instance = new CityLinkage(me, options)));
      }
      if($.type(options) === "string") return instance[options]();
    });
  };

  $.fn.CityLinkage.defaults = {
    url : 'server.php'
  }

  $(function(){
    $('[data-CityLinkage]').CityLinkage();
  });

})(jQuery)
