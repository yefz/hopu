<?php
header("content-type:text/html;charset=utf-8");

// $tier   = $_REQUEST['rank'];
// $site   = $_REQUEST['site'];
// $isNext = $_REQUEST['next'];
// echo $tier.$site.$isNext;

$data = json_decode(file_get_contents('city.json'));
$arr  = array();
// print_r($data[0]);

for($i=0;$i<count($data);$i++){
  array_push($arr,$data[$i]->name);
}
echo json_encode($arr);


// switch ($tier) {
//   case '0':

//     break;
//   case '1':
//     echo "B";
//     break;
//   case '2':
//     echo "C";
//     break;
//   default:
//     break;
// }




?>
